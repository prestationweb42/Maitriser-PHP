<?php
    echo "Coucou";
?>

coucou